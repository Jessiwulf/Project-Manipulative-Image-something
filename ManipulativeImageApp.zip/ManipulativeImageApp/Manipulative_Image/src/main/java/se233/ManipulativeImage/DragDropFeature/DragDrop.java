package se233.ManipulativeImage.DragDropFeature;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import javafx.scene.text.TextAlignment;

import java.io.File;
import java.util.List;
import java.util.function.Consumer;

public class DragDrop extends StackPane {
    //No use now
    // A consumer that will handle the list of files dropped onto the component
    private final Consumer<List<File>> onFilesDroppedHandler;

    // Constructor to initialize the DragAndDropFeature
    public DragDrop(Consumer<List<File>> onFilesDroppedHandler) {
        // Assign the provided handler to the class variable
        this.onFilesDroppedHandler = onFilesDroppedHandler;

        // Create a label to instruct the user
        Label messageLabel = new Label("Drag and drop image files or ZIP archives here");
        messageLabel.setWrapText(true); // Allow the text to wrap
        messageLabel.setTextAlignment(TextAlignment.CENTER); // Center-align the text
        messageLabel.setAlignment(Pos.CENTER); // Center the label in the StackPane

        // Add the label to the StackPane
        this.getChildren().add(messageLabel);
        // Set the style of the StackPane with a dashed border
        this.setStyle("-fx-border-color: #7a7a7a; -fx-border-width: 2; -fx-border-style: dashed;");

        // Setup the drag and drop event handlers
        setupDragDrop();
    }

    // Method to set up the drag and drop functionality
    private void setupDragDrop() {
        // Register event handlers for drag events
        this.setOnDragOver(this::handleDragOver);
        this.setOnDragEntered(this::handleDragEnter);
        this.setOnDragExited(this::handleDragExit);
        this.setOnDragDropped(this::handleDragDropped);
    }

    // Handler for drag over event
    private void handleDragOver(DragEvent event) {
        // Check if the dragboard has files
        if (event.getDragboard().hasFiles()) {
            event.acceptTransferModes(TransferMode.COPY); // Accept copy transfer mode
        }
        event.consume(); // Consume the event to indicate it has been handled
    }

    // Handler for drag entered event
    private void handleDragEnter(DragEvent event) {
        // Change the border color to indicate that files can be dropped
        this.setStyle("-fx-border-color: #1aff00; -fx-border-width: 2; -fx-border-style: dashed;");
        event.consume(); // Consume the event
    }

    // Handler for drag exited event
    private void handleDragExit(DragEvent event) {
        // Reset the border color when the drag exits
        this.setStyle("-fx-border-color: #c80000; -fx-border-width: 2; -fx-border-style: dashed;");
        event.consume(); // Consume the event
    }

    // Handler for drag dropped event
    private void handleDragDropped(DragEvent event) {
        Dragboard db = event.getDragboard(); // Get the dragboard from the event
        boolean success = false; // Initialize success status
        // Check if the dragboard has files
        if (db.hasFiles()) {
            // Pass the list of dropped files to the handler
            onFilesDroppedHandler.accept(db.getFiles());
            success = true; // Set success to true if files were handled
        }
        event.setDropCompleted(success); // Indicate whether the drop was successful
        event.consume(); // Consume the event
    }
}
