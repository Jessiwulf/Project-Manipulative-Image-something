package se233.ManipulativeImage.Main;

import javafx.fxml.FXML;
import java.util.logging.Logger;

public class MainMenuController {

    // Logger for tracking events and errors within this class
    private static final Logger logger = Logger.getLogger(MainMenuController.class.getName());

    // Method to handle the edge detection action triggered from the UI
    @FXML
    private void handleDetectEdge() {
        try {
            // Get the instance of MainViewController to delegate the action
            MainViewController mainViewController = MainViewController.getInstance();
            // Check if the instance is valid before calling the method
            if (mainViewController != null) {
                mainViewController.handleDetectEdge(); // Call the edge detection method
                logger.info("Edge detection initiated."); // Log the action
            } else {
                logger.warning("MainViewController instance is null."); // Log a warning if the instance is null
            }
        } catch (Exception e) {
            // Log any exceptions that occur during the method execution
            logger.severe("Error during edge detection: " + e.getMessage());
        }
    }

    // Method to handle the cropping action triggered from the UI
    @FXML
    private void handleCrop() {
        try {
            // Get the instance of MainViewController to delegate the action
            MainViewController mainViewController = MainViewController.getInstance();
            // Check if the instance is valid before calling the method
            if (mainViewController != null) {
                mainViewController.handleCrop(); // Call the cropping method
                logger.info("Crop initiated."); // Log the action
            } else {
                logger.warning("MainViewController instance is null."); // Log a warning if the instance is null
            }
        } catch (Exception e) {
            // Log any exceptions that occur during the method execution
            logger.severe("Error during cropping: " + e.getMessage());
        }
    }

    // Method to handle the refresh action triggered from the UI
//    @FXML
//    private void handleRefresh() {
//        try {
//            // Get the instance of MainViewController to delegate the action
//            MainViewController = MainViewController.getInstance();
//            // Check if the instance is valid before calling the method
//            if (mainViewController != null) {
//                mainViewController.refresh(); // Call the refresh method
//                logger.info("Refresh initiated."); // Log the action
//            } else {
//                logger.warning("MainViewController instance is null."); // Log a warning if the instance is null
//            }
//        } catch (Exception e) {
//            // Log any exceptions that occur during the method execution
//            logger.severe("Error during refresh: " + e.getMessage());
//        }
//    }
}
