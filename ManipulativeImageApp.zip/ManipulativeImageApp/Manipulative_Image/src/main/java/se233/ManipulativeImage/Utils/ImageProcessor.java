package se233.ManipulativeImage.Utils;

import javafx.scene.image.*;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

public class ImageProcessor {

    // Converts a JavaFX Image to a BufferedImage
    public static BufferedImage fromFXImage(Image img) {
        // Get the width and height of the JavaFX image
        int width = (int) img.getWidth();
        int height = (int) img.getHeight();

        // Create a BufferedImage with the same dimensions and an ARGB color model
        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        // Get the pixel reader for the JavaFX image
        PixelReader pixelReader = img.getPixelReader();
        // Get the writable raster for the BufferedImage to manipulate pixel data
        WritableRaster raster = bufferedImage.getRaster();

        // Loop through each pixel in the JavaFX image
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                // Retrieve the color of the current pixel
                javafx.scene.paint.Color color = pixelReader.getColor(x, y);
                // Set the pixel in the BufferedImage's raster with the ARGB values
                raster.setPixel(x, y, new int[]{
                        (int) (color.getRed() * 255),   // Red component
                        (int) (color.getGreen() * 255), // Green component
                        (int) (color.getBlue() * 255),  // Blue component
                        (int) (color.getOpacity() * 255) // Alpha (opacity) component
                });
            }
        }

        // Return the converted BufferedImage
        return bufferedImage;
    }
}
