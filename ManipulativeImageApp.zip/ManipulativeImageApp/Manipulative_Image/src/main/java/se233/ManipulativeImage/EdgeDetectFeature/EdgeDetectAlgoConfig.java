package se233.ManipulativeImage.EdgeDetectFeature;

import javafx.scene.image.*;

// Interface defining the contract for edge detection algorithms
public interface EdgeDetectAlgoConfig {
    /**
     * Applies the edge detection algorithm to the given input image.
     *
     * @param input   The image on which to apply the edge detection.
     * @param strength An integer representing the strength of the edge detection.
     */
    Image apply(Image input, int strength);
}
