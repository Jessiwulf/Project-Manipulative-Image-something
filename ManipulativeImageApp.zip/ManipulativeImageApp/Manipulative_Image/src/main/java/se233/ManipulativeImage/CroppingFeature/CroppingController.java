package se233.ManipulativeImage.CroppingFeature;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Bounds;
import javafx.geometry.Rectangle2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.ScrollPane;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.WritableImage;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


public class CroppingController {
    // Button declarations for various functionalities in the application
    public Button Select_Button;       // Button to select an image
    public Button Crop_Button;         // Button to initiate cropping of the selected image
    public Button Save_Button;         // Button to save the cropped image
    public Button Clear_Select_Button; // Button to clear the current selection
    public Button Clear_Image_Button;  // Button to clear the displayed image
    public Button SaveAll_Button;      // Button to save all processed images
    public Button Upload_Button;       // Button to upload an image

    // UI components linked to the FXML file
    @FXML
    private ListView<String> myListView; // ListView to display the names or descriptions of images

    @FXML
    private ImageView imageView;         // ImageView to show the currently selected image

    @FXML
    private BorderPane imagePane;        // BorderPane for layout management of image components

    @FXML
    private ScrollPane imageScroll;      // ScrollPane to allow scrolling of the image if it exceeds the viewable area

    @FXML
    Label statusLabel;                   // Label to show the status messages to the user

    // Crop class instance to handle image cropping functionality
    private Crop crop;

    // List to hold input items for the ListView
    private final List<String> inputListView = new ArrayList<String>();

    // Flag to indicate if the crop operation is confirmed
    private volatile boolean cropConfirmed;

    // Rectangle to represent the selection area for cropping
    private Rectangle selectionRectangle;

    // ExecutorService for handling batch processing of images
    private ExecutorService batchExecutorService;

    // Initialization method where components are set up
    @FXML
    private void initialize() {
        crop = new Crop(imageView, imagePane, imageScroll); // Initialize the Crop object with the required UI components
        DragAndDropCrop(); // Set up drag-and-drop functionality for cropping
    }

    public static class Crop {
        // Instance variables for UI components and crop logic
        private final ImageView imageView;       // The ImageView displaying the image to be cropped
        private final BorderPane imagePane;       // The main pane containing the image
        private final ScrollPane imageScroll;     // ScrollPane to enable scrolling of the image
        private Runnable onCropConfirmed;          // Callback to execute when cropping is confirmed
        private ResizableRectangle selectionRectangle; // Rectangle used for selecting the crop area
        Rectangle darkArea;                        // Rectangle overlay to darken the area outside the selection
        boolean isAreaSelected = false;            // Flag indicating if a selection area is currently selected
        private boolean isCroppingActive = false;  // Flag indicating if cropping is currently active

        // Constructor initializes the Crop object with the necessary UI components
        public Crop(ImageView imageView, BorderPane imagePane, ScrollPane imageScroll) {
            this.imageView = imageView;
            this.imagePane = imagePane;
            this.imageScroll = imageScroll;
            setupCropArea(); // Set up the dark overlay area for cropping
        }

        // Method to set up the dark overlay area
        private void setupCropArea() {
            darkArea = new Rectangle(); // Create the dark area rectangle
            darkArea.setFill(Color.color(0, 0, 0, 0.5)); // Set its color and transparency
            darkArea.setVisible(false); // Initially hidden
            imagePane.getChildren().add(darkArea); // Add it to the main pane
        }

        // Method to start the selection process for cropping
        public void startSelect() {
            isCroppingActive = true; // Activate cropping mode
            imageScroll.setPannable(false); // Disable scrolling during selection
            removeSelection(); // Ensure no previous selection exists

            // Get the bounds of the image being viewed
            Bounds imageBounds = imageView.getBoundsInParent();
            double imageWidth = imageBounds.getWidth();
            double imageHeight = imageBounds.getHeight();

            // Define the initial size and position for the selection rectangle
            double rectWidth = imageWidth / 2.5; // Set width to a fraction of the image width
            double rectHeight = imageHeight / 2.5; // Set height to a fraction of the image height
            double rectX = imageBounds.getMinX() + (imageWidth - rectWidth) / 2; // Center the rectangle horizontally
            double rectY = imageBounds.getMinY() + (imageHeight - rectHeight) / 2; // Center the rectangle vertically

            // Create the resizable rectangle for selection
            selectionRectangle = new ResizableRectangle(rectX, rectY, rectWidth, rectHeight, imagePane, this::updateDarkArea);
            selectionRectangle.setImageView(imageView); // Associate it with the image view

            isAreaSelected = true; // Mark that an area is selected
            updateDarkArea(); // Update the dark area overlay
            imagePane.requestFocus(); // Request focus on the image pane
        }

        // Method to perform cropping action
        public void Cropping() {
            if (isAreaSelected && selectionRectangle != null) { // Check if an area is selected
                imageScroll.setPannable(true); // Enable scrolling after cropping
                cropImage(selectionRectangle.getBoundsInParent()); // Crop the selected area
                removeSelection(); // Remove the selection rectangle
                selectionRectangle = null; // Clear the reference to the selection rectangle
                isAreaSelected = false; // Mark that no area is selected
                darkArea.setVisible(false); // Hide the dark area
                isCroppingActive = false; // Deactivate cropping mode
            }
            if (onCropConfirmed != null) { // Execute the callback if set
                onCropConfirmed.run();
            }
        }

        // Method to set the callback for when cropping is confirmed
        public void setOnCropConfirmed(Runnable onCropConfirmed) {
            this.onCropConfirmed = onCropConfirmed;
        }

        // Method to crop the image based on the selected rectangle bounds
        private void cropImage(Bounds bounds) {
            SnapshotParameters parameters = new SnapshotParameters();
            parameters.setFill(Color.TRANSPARENT); // Set background fill to transparent for cropping
            parameters.setViewport(new Rectangle2D(bounds.getMinX(), bounds.getMinY(), bounds.getWidth(), bounds.getHeight())); // Define the viewport based on the selected bounds
            WritableImage croppedImageWritable = new WritableImage((int) bounds.getWidth(), (int) bounds.getHeight()); // Create a writable image for the cropped result
            imageView.snapshot(parameters, croppedImageWritable); // Capture the image
            imageView.setImage(croppedImageWritable); // Set the cropped image back to the ImageView
        }

        // Method to update the dark overlay area based on the current selection
        private void updateDarkArea() {
            if (selectionRectangle != null) {
                Bounds imageBounds = imageView.getBoundsInParent(); // Get the image bounds

                // Update the dark area dimensions and position
                darkArea.setWidth(imageBounds.getWidth());
                darkArea.setHeight(imageBounds.getHeight());
                darkArea.setLayoutX(imageBounds.getMinX());
                darkArea.setLayoutY(imageBounds.getMinY());

                // Create shapes to define the visible area
                Rectangle outerRect = new Rectangle(0, 0, imageBounds.getWidth(), imageBounds.getHeight()); // Outer rectangle covering the image
                Rectangle innerRect = new Rectangle(
                        selectionRectangle.getX() - imageBounds.getMinX(),
                        selectionRectangle.getY() - imageBounds.getMinY(),
                        selectionRectangle.getWidth(),
                        selectionRectangle.getHeight()
                ); // Inner rectangle covering the selected area

                // Subtract inner rectangle from outer rectangle to create a clipping effect
                Shape clippedArea = Shape.subtract(outerRect, innerRect);

                darkArea.setClip(clippedArea); // Set the dark area to clip based on selection
                darkArea.setVisible(true); // Make the dark area visible
            }
        }

        // Method to remove the current selection and reset states
        public void removeSelection() {
            if (selectionRectangle != null) { // Check if a selection exists
                selectionRectangle.removeResizeHandle(imagePane); // Remove resize handles from the selection rectangle
                imagePane.getChildren().remove(selectionRectangle); // Remove the rectangle from the pane
                selectionRectangle = null; // Clear the reference
            }
            isAreaSelected = false; // Mark that no area is selected
        }
    }

    private void DragAndDropCrop() {
        // Handling drag events on the ListView
        myListView.setOnDragOver(event -> {
            Dragboard dragboard = event.getDragboard(); // Get the Dragboard from the event
            // Check if the dragged item contains files
            if (dragboard.hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY); // Accept copy transfer mode
            }
            event.consume(); // Consume the event to indicate it has been handled
        });

        // Handling drop events on the ListView
        myListView.setOnDragDropped(event -> {
            boolean success = false; // Flag to track if the drop was successful
            Dragboard dragboard = event.getDragboard(); // Get the Dragboard from the event

            // Check if the dropped item contains files
            if (dragboard.hasFiles()) {
                List<File> files = dragboard.getFiles(); // Get the list of files from the dragboard
                for (File file : files) {
                    try {
                        // Check if the dropped file is an image
                        if (isImageFile(file)) {
                            inputListView.add(file.getAbsolutePath()); // Add the file's path to the input list
                            myListView.getItems().add(file.getName()); // Add the file's name to the ListView
                            imageView.setImage(new Image(file.toURI().toString())); // Display the image in the ImageView
                            handleClearSelectAreaButton(); // Clear any selection area if applicable
                            setStatus("Dropped file: " + file.getName()); // Update status
                            success = true; // Mark the drop as successful
                        } else if (file.getName().toLowerCase().endsWith(".zip")) { // Check if the file is a ZIP file
                            try {
                                // Extract files from the ZIP file
                                List<File> extractedFiles = extractZipFile(file);
                                for (File extractedFile : extractedFiles) {
                                    // Check if the extracted file is an image
                                    if (isImageFile(extractedFile)) {
                                        inputListView.add(extractedFile.getAbsolutePath()); // Add the extracted file's path
                                        myListView.getItems().add(extractedFile.getName()); // Add the extracted file's name to the ListView
                                        handleClearSelectAreaButton(); // Clear any selection area if applicable
                                        setStatus("ZIP file dropped and extracted. Loaded " + inputListView.size() + " images."); // Update status
                                    }
                                }
                                success = true; // Mark the drop as successful
                            } catch (IOException e) {
                                e.printStackTrace(); // Print stack trace for any IO exceptions
                            }
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e); // Throw a runtime exception if there's an error handling the file
                    }
                }
            }

            event.setDropCompleted(success); // Set the drop completion status
            event.consume(); // Consume the event
        });

        // Handling double-click events on the ListView to load the selected image
        myListView.setOnMouseClicked((MouseEvent event) -> {
            if (event.getClickCount() == 2) { // Check for double-click
                String selectedFileName = myListView.getSelectionModel().getSelectedItem(); // Get the selected file name
                if (selectedFileName != null) {
                    handleClearSelectAreaButton(); // Clear any selection area if applicable
                    int index = myListView.getSelectionModel().getSelectedIndex(); // Get the index of the selected item
                    String filePath = inputListView.get(index); // Get the corresponding file path
                    File file = new File(filePath); // Create a File object for the selected file
                    Image image = new Image(file.toURI().toString()); // Load the image
                    imageView.setImage(image); // Display the image in the ImageView

                    setStatus("File: " + selectedFileName); // Update status
                }
            }
        });
    }

    private List<File> extractZipFile(File zipFile) throws IOException {
        List<File> extractedFiles = new ArrayList<>(); // List to hold extracted files
        File tempDir = new File("extracted"); // Temporary directory for extracted files
        // Create the directory if it doesn't exist
        if (!tempDir.exists()) {
            tempDir.mkdir(); // Create the "extracted" directory
        }

        // Use try-with-resources to ensure ZipInputStream is closed properly
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry zipEntry;
            // Loop through each entry in the ZIP file
            while ((zipEntry = zis.getNextEntry()) != null) {
                // Create a new file for each entry
                File newFile = new File(tempDir, zipEntry.getName());
                // Create parent directories if they do not exist
                if (!newFile.getParentFile().exists()) {
                    newFile.getParentFile().mkdirs(); // Create necessary directories
                }

                // Check if the entry is not a directory
                if (!zipEntry.isDirectory()) {
                    // Copy the entry to the new file
                    Files.copy(zis, newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    extractedFiles.add(newFile); // Add the new file to the list
                }
                zis.closeEntry(); // Close the current entry
            }
        }
        return extractedFiles; // Return the list of extracted files
    }

    private boolean isImageFile(File file) throws IOException {
        String fileName = file.getName().toLowerCase(); // Get the file name in lower case
        // Check if the file ends with specific image extensions
        return fileName.endsWith(".png") || fileName.endsWith(".jpg") || fileName.endsWith(".jpeg");
    }

    @FXML
    public void handleUploadImageButton() throws IOException {
        FileChooser fileChooser = new FileChooser(); // Create a file chooser for selecting files
        fileChooser.getExtensionFilters().addAll( // Add filters for image and ZIP files
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("ZIP Files", "*.zip")
        );

        File selectedFile = fileChooser.showOpenDialog(null); // Show the file chooser dialog
        if (selectedFile == null) {
            // If no file was selected, show a message and return
            showInformation("Cancel Upload", "You have not selected a file");
            setStatus("You have not selected a file, please select again");
            return;
        }

        // Clear any existing selection if an image is currently displayed
        if (imageView.getImage() != null) {
            handleClearSelectAreaButton();
        }

        // Check if a valid file was selected
        if (selectedFile != null) {
            try {
                // Check if the selected file is an image
                if (isImageFile(selectedFile)) {
                    inputListView.add(selectedFile.getAbsolutePath()); // Add the image path to the list
                    myListView.getItems().add(selectedFile.getName()); // Add the image name to the ListView
                    setStatus("Image loaded successfully."); // Update status message

                    // Load the selected image into the ImageView
                    imageView.setImage(new Image(selectedFile.toURI().toString()));
                }
                // Check if the selected file is a ZIP file
                else if (selectedFile.getName().toLowerCase().endsWith(".zip")) {
                    try {
                        // Extract files from the ZIP archive
                        List<File> extractedFiles = extractZipFile(selectedFile);
                        for (File extractedFile : extractedFiles) {
                            // Add image files from the extracted files to the list
                            if (isImageFile(extractedFile)) {
                                inputListView.add(extractedFile.getAbsolutePath()); // Add image path to the list
                                myListView.getItems().add(extractedFile.getName()); // Add image name to the ListView
                                setStatus("ZIP file extracted successfully. Loaded " + inputListView.size() + " images."); // Update status message
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace(); // Print stack trace for any IOException during extraction
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e); // Rethrow any IOException as a RuntimeException
            }
        }
    }

    @FXML
    public void handleSelectAreaButton() {
        // Check if there is an image loaded in the ImageView
        if (imageView.getImage() != null) {
            crop.startSelect(); // Start the cropping selection process
            setStatus("Selecting area"); // Update status message
        }
        // If no image is loaded or no item is selected in the ListView
        else if (imageView.getImage() == null || myListView.getSelectionModel().getSelectedItem() == null) {
            showInformation("No Image", "Please drop or select an image"); // Show an information dialog
        }
    }

    @FXML
    public void handleClearSelectAreaButton() {
        // Check if an area has been selected for cropping
        if (!crop.isAreaSelected) {
            setStatus("No select area, please select area"); // Update status if no area is selected
            return; // Exit the method
        }

        // If a selection rectangle exists, remove it from the image pane
        if (selectionRectangle != null) {
            imagePane.getChildren().remove(selectionRectangle); // Remove selection rectangle from pane
            selectionRectangle = null; // Clear reference to the selection rectangle
        }

        crop.isAreaSelected = false; // Update crop state

        // Hide the dark area overlay
        if (crop.darkArea != null) {
            crop.darkArea.setVisible(false);
        }

        imagePane.requestFocus(); // Request focus on the image pane
        resetCropHandler(); // Reset the crop handler to its initial state
        setStatus("Selection cleared"); // Update status message
    }

    @FXML
    private void resetCropHandler() {
        // Check if the crop object exists
        if (crop != null) {
            crop.removeSelection(); // Remove any existing selection
            crop = new Crop(imageView, imagePane, imageScroll); // Create a new Crop object
        }
    }

    @FXML
    public void handleClearImageButton() {
        // Check if there's no batch process running and no images to clear
        if (batchExecutorService == null && imageView.getImage() == null && myListView.getItems().isEmpty()) {
            showInformation("No Image to clear", "Please upload or drag image"); // Show information dialog
            setStatus("No image, please upload or drag image"); // Update status
            return; // Exit the method
        }

        handleClearSelectAreaButton(); // Clear any selection area

        // Check if a batch executor service exists and is not shut down
        if (batchExecutorService != null && !batchExecutorService.isShutdown()) {
            batchExecutorService.shutdownNow(); // Shutdown the batch executor
            batchExecutorService = null; // Clear reference to the batch executor service
        }

        // Clear input and ListView items
        if (!inputListView.isEmpty()) {
            inputListView.clear(); // Clear input list
        }

        if (!myListView.getItems().isEmpty()) {
            myListView.getItems().clear(); // Clear ListView items
        }

        // Clear the image from the ImageView
        if (imageView.getImage() != null) {
            imageView.setImage(null); // Clear the displayed image
        }

        showInformation("Images Cleared", "All images and batch processes have been cleared."); // Show confirmation dialog
        setStatus("Images Cleared"); // Update status message
    }

    @FXML
    private void handleCropButton() {
        // Check if an image is loaded in the imageView
        if (imageView.getImage() == null) {
            statusLabel.setText("Please select area"); // Update status if no image is loaded
            showInformation("Area not found", "Please select area"); // Inform user
            return; // Exit the method
        }

        // Check if an area is selected for cropping
        if (!crop.isAreaSelected) {
            statusLabel.setText("Please select an area"); // Update status if no area is selected
            showInformation("Area not selected", "Please select an area to crop"); // Inform user
            return; // Exit the method
        }

        // Perform the cropping operation
        crop.Cropping(); // Crop the image based on the selected area
        cropConfirmed = true; // Indicate that the crop operation has been confirmed
        setStatus("Image cropped"); // Update status message
    }

    @FXML
    private void handleSaveButton() {
        // Check if no crop has been confirmed and no area is selected
        if (!cropConfirmed && !crop.isAreaSelected) {
            showInformation("No crop image", "Please crop image first"); // Inform user
            return; // Exit the method
        }

        // Create a file chooser for saving the cropped image
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Image"); // Set the title of the file chooser
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Save as png", "*.png")); // Filter for PNG
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Save as jpg", "*.jpg")); // Filter for JPG
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Save as jpeg", "*.jpeg")); // Filter for JPEG
        File file = fileChooser.showSaveDialog(imageView.getScene().getWindow()); // Show save dialog

        // Check if a file was selected
        if (file != null) {
            try {
                // Convert the ImageView image to a BufferedImage
                BufferedImage bufferedImage = SwingFXUtils.fromFXImage(imageView.getImage(), null);
                // Save the image in PNG format
                ImageIO.write(bufferedImage, "png", file);
                // Write to the same file multiple times
                ImageIO.write(bufferedImage, "jpg", file); // Not valid for same file
                ImageIO.write(bufferedImage, "jpeg", file); // Not valid for same file
                showInformation("Saved Image", "Image saved to " + file.getAbsolutePath()); // Inform user of success
                setStatus("Selecting area"); // Update status message
            } catch (IOException e) {
                e.printStackTrace(); // Print stack trace for debugging
            }
        } else {
            showInformation("File not saved yet", "You have canceled the save file"); // Inform user of cancellation
        }
    }

    @FXML
    public void handleSaveAllButton(ActionEvent event) {
        // Check if the input list is empty
        if (inputListView.isEmpty()) {
            showInformation("No Images", "Please add images to the list first."); // Inform user
            setStatus("No Image to be processed, please add"); // Update status message
            return; // Exit the method
        }

        try {
            // Create a directory chooser for selecting the output directory
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("Select Output Directory"); // Set the title of the directory chooser
            File outputDir = directoryChooser.showDialog(imageView.getScene().getWindow()); // Show dialog

            // Check if a directory was selected
            if (outputDir == null) {
                throw new IllegalArgumentException("No output directory selected."); // Throw an exception if not
            }

            configureCroppingForAllImages(outputDir); // Configure cropping for all images
            setStatus("Batch processing started."); // Update status message
        } catch (IllegalArgumentException e) {
            showAlert("Invalid Directory", e.getMessage()); // Show an alert if no directory is selected
        }
    }

    private void configureCroppingForAllImages(File outputDir) {
        // Start processing from the first image
        configureNextImage(0, outputDir, new ArrayList<>());
    }

    private void configureNextImage(int currentIndex, File outputDir, List<Image> croppedImages) {
        // If we've processed all images, start concurrent processing
        if (currentIndex >= inputListView.size()) {
            startConcurrentProcessing(croppedImages, outputDir);
            return;
        }

        String filePath = inputListView.get(currentIndex); // Get the current image path
        File file = new File(filePath); // Create a File object from the path

        try {
            // Check if the current file is an image
            if (isImageFile(file)) {
                Image image = new Image(file.toURI().toString()); // Load the image
                imageView.setImage(image); // Set it in the ImageView
                handleClearSelectAreaButton(); // Clear any previously selected area

                // Set the crop confirmation action
                crop.setOnCropConfirmed(() -> {
                    croppedImages.add(imageView.getImage()); // Add cropped image to the list
                    configureNextImage(currentIndex + 1, outputDir, croppedImages); // Process the next image
                });
            }
        } catch (IOException e) {
            throw new RuntimeException(e); // Handle IO exceptions
        }
    }

    private void startConcurrentProcessing(List<Image> croppedImages, File outputDir) {
        // Create a thread pool for processing images
        ExecutorService executorService = Executors.newFixedThreadPool(4); // Use 4 threads (adjust as needed)
        List<Runnable> tasks = new ArrayList<>(); // List to hold tasks

        // Prepare tasks for processing each cropped image
        for (int i = 0; i < croppedImages.size(); i++) {
            Image image = croppedImages.get(i);
            String fileName = new File(inputListView.get(i)).getName(); // Get the original file name

            // Define the task for processing
            tasks.add(() -> {
                try {
                    Image processedImage = detectImageEdges(image); // Process image edges
                    saveProcessedImage(processedImage, outputDir, fileName); // Save processed image
                } catch (IOException e) {
                    e.printStackTrace(); // Print stack trace for debugging
                    showAlert("Error", "Failed to save processed image: " + fileName); // Alert on failure
                }
            });
        }

        // Submit all tasks to the executor
        for (Runnable task : tasks) {
            executorService.submit(task);
        }

        executorService.shutdown(); // Shutdown the executor service
        imageView.setImage(null); // Clear the image view after processing
        showInformation("Batch Processing Complete", "All images have been processed and saved."); // Notify completion
        setStatus("Batch Processing Complete"); // Update status
    }

    private Image detectImageEdges(Image croppedImage) {
        // Placeholder method for edge detection (currently just returns the image)
        return croppedImage;
    }

    private void saveProcessedImage(Image image, File outputDir, String originalFileName) throws IOException {
        // Create a new file name for the processed image
        String outputFileName = originalFileName.substring(0, originalFileName.lastIndexOf('.')) + "_processed.png";
        File outputFile = new File(outputDir, outputFileName); // Create a new file in the output directory
        BufferedImage bufferedImage = SwingFXUtils.fromFXImage(image, null); // Convert to BufferedImage
        ImageIO.write(bufferedImage, "png", outputFile); // Save the image as PNG
    }

    //Just set status
    private void setStatus(String message) {
        statusLabel.setText("Status: " + message);
    }

    //Just show alert info
    private void showInformation(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();

    }

    //Just normal alert
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}