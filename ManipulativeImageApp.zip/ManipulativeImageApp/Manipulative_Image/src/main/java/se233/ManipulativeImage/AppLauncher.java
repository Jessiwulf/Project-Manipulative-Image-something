package se233.ManipulativeImage;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class AppLauncher extends Application {
    public static Stage primaryStage;

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        URL fxmlUrl = getClass().getResource("/se233/ManipulativeImage/FXMLFiles/Main_View.fxml");
        if (fxmlUrl == null) {
            System.err.println("FXML file not found!");
            return;
        }
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/se233/ManipulativeImage/FXMLFiles/Main_View.fxml"));
        Parent root = fxmlLoader.load();
        primaryStage.setTitle("Manipulative Image Application");
        //Can add app window size here
        //Like -> primaryStage.setScene(new Scene(root, 800, 700));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}