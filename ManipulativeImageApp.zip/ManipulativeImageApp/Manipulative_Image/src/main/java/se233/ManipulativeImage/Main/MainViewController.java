package se233.ManipulativeImage.Main;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainViewController implements Initializable {
    // Singleton instance of MainViewController
    private static MainViewController instance;

    @FXML private VBox contentArea; // The main content area where different views are loaded
//    @FXML private Menu mainMenu;
//    @FXML private Menu croppingMenu;
//    @FXML private Menu edgeDetectionMenu;
//    @FXML private Menu exit;

// Returns the singleton instance of MainViewController
public static MainViewController getInstance() {
    return instance;
}

    // Initializes the controller and loads the main menu view
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        instance = this; // Set the singleton instance to this controller
        loadView("/se233/ManipulativeImage/FXMLFiles/Main_Menu_Pane.fxml"); // Load the main menu pane
    }

    // Handles the action to switch to the main menu view
    @FXML
    public void handleMainMenu() {
        loadView("/se233/ManipulativeImage/FXMLFiles/Main_Menu_Pane.fxml");
    }

    // Handles the action to switch to the cropping view
    @FXML
    public void handleCrop() {
        loadView("/se233/ManipulativeImage/FXMLFiles/Cropping_Pane.fxml");
    }

    // Handles the action to switch to the edge detection view
    @FXML
    public void handleDetectEdge() {
        loadView("/se233/ManipulativeImage/FXMLFiles/Edge_Detection_Pane.fxml");
    }

    // Handles the action to exit the application with confirmation dialog
    @FXML
    private void handleExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION); // Create a confirmation alert
        alert.setTitle("Confirmation");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("Please confirm your exit.");

        // Show the alert and check user response
        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            System.exit(0); // Exit the application if confirmed
        }
    }

    // Loads a new view into the content area based on the provided FXML path
    private void loadView(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath)); // Load the FXML file
            Parent view = loader.load(); // Create the view
            contentArea.getChildren().clear(); // Clear existing content in the area
            contentArea.getChildren().add(view); // Add the new view to the content area
        } catch (IOException e) {
            e.printStackTrace(); // Print stack trace for debugging
            showErrorDialog("Failed to load view: " + e.getMessage()); // Show error dialog on failure
        }
    }

    // Displays an error dialog with a given message
    private void showErrorDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR); // Create an error alert
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message); // Set the error message
        alert.showAndWait(); // Show the alert and wait for user response
    }

//    private void updateMenus() {
//        // Clear existing items from menus
//        mainMenu.getItems().clear();
//        croppingMenu.getItems().clear();
//        edgeDetectionMenu.getItems().clear();
//        exit.getItems().clear();
//
//        // Main Menu
//        MenuItem refreshMainMenu = new MenuItem("Refresh Main Menu");
//        refreshMainMenu.setOnAction(e -> handleMainMenu());
//        mainMenu.getItems().add(refreshMainMenu);
//
//        MenuItem goToCropFromMainMenu = new MenuItem("Go to Cropping Page");
//        goToCropFromMainMenu.setOnAction(e -> handleCrop());
//        mainMenu.getItems().add(goToCropFromMainMenu);
//
//        MenuItem goToEdgeFromMainMenu = new MenuItem("Go to Detect Edge Page");
//        goToEdgeFromMainMenu.setOnAction(e -> handleDetectEdge());
//        mainMenu.getItems().add(goToEdgeFromMainMenu);
//
//        MenuItem ExitFromMainMenu = new MenuItem("Exit");
//        ExitFromMainMenu.setOnAction(e -> handleExit());
//        mainMenu.getItems().add(ExitFromMainMenu);
//
//        // Cropping Feature
//        MenuItem refreshCrop = new MenuItem("Refresh Cropping Page");
//        refreshCrop.setOnAction(e -> handleCrop());
//        croppingMenu.getItems().add(refreshCrop);
//
//        MenuItem goToHomeFromCrop = new MenuItem("Go to Main Menu");
//        goToHomeFromCrop.setOnAction(e -> handleMainMenu());
//        croppingMenu.getItems().add(goToHomeFromCrop);
//
//        MenuItem goToEdgeFromCrop = new MenuItem("Go to Detect Edge Page");
//        goToEdgeFromCrop.setOnAction(e -> handleDetectEdge());
//        croppingMenu.getItems().add(goToEdgeFromCrop);
//
//        MenuItem ExitFromCrop = new MenuItem("Exit");
//        ExitFromCrop.setOnAction(e -> handleExit());
//        croppingMenu.getItems().add(ExitFromCrop);
//
//        // Detect Edge Feature
//        MenuItem refreshEdge = new MenuItem("Refresh Edge Detection Page");
//        refreshEdge.setOnAction(e -> handleDetectEdge());
//        edgeDetectionMenu.getItems().add(refreshEdge);
//
//        MenuItem goToHomeFromEdge = new MenuItem("Go to Main Menu");
//        goToHomeFromEdge.setOnAction(e -> handleMainMenu());
//        edgeDetectionMenu.getItems().add(goToHomeFromEdge);
//
//        MenuItem goToCropFromEdge = new MenuItem("Go to Cropping Page");
//        goToCropFromEdge.setOnAction(e -> handleCrop());
//        edgeDetectionMenu.getItems().add(goToCropFromEdge);
//
//        MenuItem ExitFromEdge = new MenuItem("Exit");
//        ExitFromEdge.setOnAction(e -> handleExit());
//        edgeDetectionMenu.getItems().add(ExitFromEdge);
//    }

}
