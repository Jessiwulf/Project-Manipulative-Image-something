package se233.ManipulativeImage.BatchProcessingFeature;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class BatchProcessing {

    /**
     * Processes a list of files. If a file is a ZIP file, it extracts image files from it.
     * If a file is an image, it adds the file to the processed list.
     *
     * @param files List of input files (can include both images and ZIP files).
     * @return List of processed image files (including images extracted from ZIP files).
     * @throws IOException If an I/O error occurs during file processing.
     */
    public static List<File> processFiles(List<File> files) throws IOException {
        // List to store processed image files
        List<File> processedFiles = new ArrayList<>();

        // Iterate through each file in the input list
        for (File file : files) {
            // If the file is a ZIP, extract images from it
            if (file.getName().toLowerCase().endsWith(".zip")) {
                processedFiles.addAll(extractZip(file));
            }
            // If the file is an image, add it to the processed list
            else if (isImageFile(file)) {
                processedFiles.add(file);
            }
        }

        return processedFiles;  // Return the list of processed files
    }

    /**
     * Extracts image files from a ZIP file.
     *
     * @param zipFile The ZIP file to extract images from.
     * @return List of extracted image files.
     * @throws IOException If an I/O error occurs during ZIP extraction.
     */
    private static List<File> extractZip(File zipFile) throws IOException {
        // List to store extracted image files
        List<File> extractedZipFiles = new ArrayList<>();
        // Create a temporary directory to store extracted files
        Path tempDir = Files.createTempDirectory("ManipulativeImageTemp_");

        // Open the ZIP file as a stream
        try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(zipFile.toPath()))) {
            ZipEntry entry;
            // Loop through each entry in the ZIP file
            while ((entry = zis.getNextEntry()) != null) {
                // Only extract files (not directories) and ensure they are images
                if (!entry.isDirectory() && isImageFile(entry.getName())) {
                    // Define the path to extract the image to
                    Path filePath = tempDir.resolve(entry.getName());
                    // Copy the image file to the temporary directory
                    Files.copy(zis, filePath);
                    // Add the extracted image file to the list
                    extractedZipFiles.add(filePath.toFile());
                }
            }
        }

        return extractedZipFiles;  // Return the list of extracted image files
    }

    /**
     * Checks if a given file is an image by name.
     *
     * @param file The file to check.
     * @return True if the file is an image, false otherwise.
     */
    private static boolean isImageFile(File file) {
        return isImageFile(file.getName());  // Delegate to string-based method
    }

    /**
     * Checks if a given file name indicates it is an image based on its extension (By file).
     *
     * @param fileName The name of the file to check.
     * @return True if the file has an image extension (.jpg, .jpeg, .png), false otherwise.
     */
    private static boolean isImageFile(String fileName) {
        // Convert file name to lowercase for case-insensitive comparison
        String lowercaseName = fileName.toLowerCase();
        // Check if the file extension is one of the supported image formats
        return lowercaseName.endsWith(".jpg") || lowercaseName.endsWith(".jpeg") || lowercaseName.endsWith(".png");
    }
}
