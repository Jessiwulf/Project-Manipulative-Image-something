package se233.ManipulativeImage.EdgeDetectFeature.Algorithms;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import se233.ManipulativeImage.EdgeDetectFeature.EdgeDetectionAlgorithm;

public class LaplacianAlgorithm implements EdgeDetectionAlgorithm {
    @Override
    public Image apply(Image input, int strength) {
        // Get image dimensions
        int width = (int) input.getWidth();
        int height = (int) input.getHeight();
        // Create a writable image for the output
        WritableImage output = new WritableImage(width, height);

        // Get pixel reader and writer
        PixelReader reader = input.getPixelReader();
        PixelWriter writer = output.getPixelWriter();

        // Define the kernel based on the strength parameter
        int[][] kernel;
        if (strength == 3) {
            kernel = new int[][]{{0, -1, 0}, {-1, 4, -1}, {0, -1, 0}}; // 3x3 kernel
        } else {
            kernel = new int[][]{{-1, -1, -1, -1, -1},
                    {-1, -1, -1, -1, -1},
                    {-1, -1, 24, -1, -1},
                    {-1, -1, -1, -1, -1},
                    {-1, -1, -1, -1, -1}}; // 5x5 kernel
        }

        // Determine the offset based on the strength
        int offset = strength / 2;

        // Iterate through each pixel in the image (excluding borders)
        for (int y = offset; y < height - offset; y++) {
            for (int x = offset; x < width - offset; x++) {
                double sum = 0;
                // Apply the kernel to the surrounding pixels
                for (int i = -offset; i <= offset; i++) {
                    for (int j = -offset; j <= offset; j++) {
                        Color c = reader.getColor(x + j, y + i); // Get color of the neighboring pixel
                        sum += c.getBrightness() * kernel[i + offset][j + offset]; // Accumulate brightness
                    }
                }
                sum = Math.abs(sum); // Take the absolute value of the sum
                sum = Math.min(1.0, sum); // Clamp the value to the range of 0-1
                Color edgeColor = Color.gray(1.0 - sum); // Invert the color for edges
                writer.setColor(x, y, edgeColor); // Write the edge color to the output image
            }
        }

        return output; // Return the processed image
    }
}
