package se233.ManipulativeImage.Models;

import javafx.scene.image.Image;
import java.io.File;

public class ImageFile {
    private File file; // The underlying file representing the image
    private Image image; // The JavaFX Image object for rendering

    // Returns the file associated with this ImageFile
    public File getFile() {
        return file;
    }

    // Sets the file associated with this ImageFile
    public void setFile(File file) {
        this.file = file;
    }

    // Returns the Image object for this ImageFile
    public Image getImage() {
        return image;
    }

    // Sets the Image object for this ImageFile
    public void setImage(Image image) {
        this.image = image;
    }

    // Constructor that initializes the ImageFile with the specified file
    public ImageFile(File file) {
        this.file = file; // Initialize the file
        // Create a new Image object using the file's URI for rendering
        this.image = new Image(file.toURI().toString());
    }
}
