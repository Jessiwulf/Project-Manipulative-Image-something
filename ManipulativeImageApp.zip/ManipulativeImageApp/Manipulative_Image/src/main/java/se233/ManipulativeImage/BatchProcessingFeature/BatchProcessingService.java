package se233.ManipulativeImage.BatchProcessingFeature;

import javafx.concurrent.Service;
import javafx.concurrent.Task;


import javax.imageio.ImageIO;
import javafx.scene.image.Image;
import se233.ManipulativeImage.EdgeDetectFeature.EdgeDetectAlgoConfig;
import se233.ManipulativeImage.Models.AllProcessing;

import se233.ManipulativeImage.Utils.ImageProcessor;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class BatchProcessingService extends Service<Void> {
    private final List<AllProcessing> jobs; // List of processing jobs to be executed
    private final Map<String, EdgeDetectAlgoConfig> algorithms; // Mapping of algorithm names to their implementations

    /**
     * Constructor for BatchProcessorService.
     *
     * @param jobs       List of processing jobs to execute.
     * @param numThreads Number of threads to use (currently unused in this implementation).
     * @param algorithms Map of edge detection algorithms.
     */
    public BatchProcessingService(List<AllProcessing> jobs, int numThreads, Map<String, EdgeDetectAlgoConfig> algorithms) {
        this.jobs = jobs;
        this.algorithms = algorithms;
    }

    /**
     * Creates a task for processing the jobs.
     *
     * @return A Task<Void> that processes the image jobs.
     */
    @Override
    protected Task<Void> createTask() {
        return new Task<>() {
            @Override
            protected Void call() throws Exception {
                int total = jobs.size(); // Total number of jobs
                AtomicInteger completed = new AtomicInteger(0); // Atomic integer to track completed jobs

                // Process jobs in parallel
                jobs.parallelStream().forEach(job -> {
                    processJob(job); // Process the current job
                    int completedCount = completed.incrementAndGet(); // Increment completed job count
                    updateProgress(completedCount, total); // Update progress of the task
                    updateMessage("Processed " + completedCount + " of " + total + " images"); // Update message
                });

                return null; // Task completed
            }
        };
    }

    /**
     * Processes a single processing job.
     *
     * @param job The processing job to execute.
     */
    private void processJob(AllProcessing job)  {
        try {
            // Load the image from the input file
            Image image = new Image(job.getInputFile().toURI().toString());
            // Retrieve the corresponding edge detection algorithm
            EdgeDetectAlgoConfig edgeAlgorithm = algorithms.get(job.getAlgorithm());

            // Check if the algorithm is supported


            // Apply the edge detection algorithm on the image
            Image processedImage = edgeAlgorithm.apply(image, job.getAlgorithm().equals("Laplacian") ? job.getMaskSize() : job.getStrength());

            // Write the processed image to the output file
            ImageIO.write(ImageProcessor.fromFXImage(processedImage), "png", job.getOutputFile());

    } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
