package se233.ManipulativeImage.EdgeDetectFeature;

import javafx.scene.image.*;

// Interface defining the contract for edge detection algorithms
public interface EdgeDetectionAlgorithm {
    /**
     * Applies the edge detection algorithm to the given input image.
     *
     * @param input   The image on which to apply the edge detection.
     * @param strength An integer representing the strength of the edge detection.
     * @return A new image with the edges detected.
     */
    Image apply(Image input, int strength);
}
