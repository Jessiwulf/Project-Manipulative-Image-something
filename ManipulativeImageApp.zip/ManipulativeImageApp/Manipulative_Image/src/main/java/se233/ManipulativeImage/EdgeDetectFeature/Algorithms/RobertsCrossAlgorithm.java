package se233.ManipulativeImage.EdgeDetectFeature.Algorithms;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import se233.ManipulativeImage.EdgeDetectFeature.EdgeDetectionAlgorithm;

public class RobertsCrossAlgorithm implements EdgeDetectionAlgorithm {
    @Override
    public Image apply(Image input, int strength) {
        // Get the dimensions of the input image
        int width = (int) input.getWidth();
        int height = (int) input.getHeight();
        // Create a writable image for the output
        WritableImage output = new WritableImage(width, height);

        // Get pixel reader and writer for the input and output images
        PixelReader reader = input.getPixelReader();
        PixelWriter writer = output.getPixelWriter();

        // Normalize strength to a factor between 0 and 2
        double strengthFactor = strength / 50.0;

        // Iterate through each pixel, excluding the last row and column
        for (int y = 0; y < height - 1; y++) {
            for (int x = 0; x < width - 1; x++) {
                // Get the colors of the current pixel and its adjacent pixels
                Color c00 = reader.getColor(x, y);
                Color c01 = reader.getColor(x, y + 1);
                Color c10 = reader.getColor(x + 1, y);
                Color c11 = reader.getColor(x + 1, y + 1);

                // Calculate gradients in the x and y directions
                double gx = c11.getBrightness() - c00.getBrightness(); // Gradient in x direction
                double gy = c10.getBrightness() - c01.getBrightness(); // Gradient in y direction

                // Calculate the magnitude of the gradient
                double magnitude = Math.sqrt(gx * gx + gy * gy) * strengthFactor;
                magnitude = Math.min(1.0, magnitude); // Clamp the magnitude to 0-1 range

                // Create the edge color based on the magnitude
                Color edgeColor = Color.gray(1.0 - magnitude); // Invert for black edges on white background
                writer.setColor(x, y, edgeColor); // Write the edge color to the output image
            }
        }

        return output; // Return the processed image
    }
}
