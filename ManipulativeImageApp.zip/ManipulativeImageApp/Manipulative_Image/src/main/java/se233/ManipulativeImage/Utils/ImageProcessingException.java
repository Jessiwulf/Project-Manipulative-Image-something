package se233.ManipulativeImage.Utils;

// Custom exception class for handling image processing errors
//public class  extends Exception {
//
//
//}
