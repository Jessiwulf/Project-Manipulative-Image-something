package se233.ManipulativeImage.EdgeDetectFeature.OldDetect;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AllCustomHandler {
    @FXML
    private Button chooseFileBtn, generateBtn, saveBtn, nextBtn, prevBtn;
    @FXML
    private ImageView preImage, postImage;
    @FXML
    private ProgressBar progressBar;
    @FXML
    private Label currentFile, fileNumber, currentFileName;
    @FXML
    private ToggleButton edgeBtn, cropBtn, prewittBtn, robertsCrossBtn, laplacianBtn;
    @FXML
    private VBox edgeParamsPane;

    private File currentFilePath;
    private ImageProcessing imageProcessingService;
    private ZipHandler zipHandler;
    private String currentMode, currentEdgeMode;
    private List<Image> processedImagesList = new ArrayList<>();
    private boolean isGenerate;

    @FXML
    private StackPane parentPane;

    @FXML
    public void initialize() {
        imageProcessingService = new ImageProcessing();
        zipHandler = new ZipHandler();
        nextBtn.setDisable(true);
        prevBtn.setDisable(true);
        saveBtn.setVisible(false);

        setMode("edge");
        setEdgeMode("prewitt");

        // Handle file selection
        chooseFileBtn.setOnAction(event -> chooseFile());
    }

    // File handler
    @FXML
    public void handleDragOver(DragEvent event) {
        if (event.getGestureSource() != preImage && event.getDragboard().hasFiles()) {
            event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }
        event.consume();
    }

    @FXML
    public void handleDrop(DragEvent event) {
        Dragboard db = event.getDragboard();
        boolean success = false;

        if (db.hasFiles()) {
            success = true;
            File file = db.getFiles().get(0);
            loadFile(file);
        }
        event.setDropCompleted(success);
        event.consume();
    }

    private void loadFile(File file) {
        String fileType = getFileType(file);

        if ("image".equals(fileType)) {
            loadImage(file);
            updateFileNumber(1, 1); // Assuming single image loaded
        } else if ("zip".equals(fileType)) {
            loadZipFile(file);
            updateFileNumber(zipHandler.getImageCount(), zipHandler.getCurrentIndex() + 1); // Update to reflect total images and current index
            prevBtn.setDisable(false);
            nextBtn.setDisable(false);
        } else {
            showError("Please drop an image file (JPEG, PNG, BMP) or a ZIP file.");
        }
    }

    private void loadImage(File file) {
        try {
            Image image = new Image(file.toURI().toString());
            preImage.setImage(image);
            currentFilePath = file;
            updateCurrentFileNameLabel();
        } catch (Exception e) {
            showError("Failed to load the image. Please try again.");
        }
    }

    private void loadZipFile(File file) {
        try {
            zipHandler.loadZipFile(file);
            showImage(zipHandler.getCurrentImage());
            updateFileNumber(zipHandler.getImageCount(), zipHandler.getCurrentIndex() + 1); // Update current image index
            currentFilePath = file;
            updateCurrentFileLabel();
        } catch (Exception e) {
            showError("Failed to load the ZIP file. Please ensure it contains valid images.");
        }
    }

    private void updateCurrentFileLabel() {
        if (zipHandler != null && zipHandler.getCurrentFile() != null) {
            currentFile.setText(zipHandler.getCurrentFile());
        }
    }

    private void updateCurrentFileNameLabel() {
        if (currentFilePath != null) {
            currentFileName.setText(currentFilePath.getName());
        } else {
            currentFileName.setText("No file selected");
        }

        if (zipHandler != null && zipHandler.getImageCount() > 0) {
            fileNumber.setText((zipHandler.getCurrentIndex() + 1) + "/" + zipHandler.getImageCount());
        } else {
            fileNumber.setText("1/1");
        }
    }

    private boolean isImageFile(File file) {
        String fileName = file.getName().toLowerCase();
        return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || fileName.endsWith(".png") || fileName.endsWith(".bmp");
    }

    @FXML
    public void handleChooseFileAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose Image or ZIP File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.jpeg", "*.png", "*.bmp"),
                new FileChooser.ExtensionFilter("ZIP Files", "*.zip")
        );

        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            loadFile(file);
        }
    }

    private void updateFileNumber(int totalFiles, int currentIndex) {
        fileNumber.setText(currentIndex + "/" + totalFiles);
    }

    private void chooseFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Images", "*.jpg", "*.png", "*.jpeg"),
                new FileChooser.ExtensionFilter("ZIP files", "*.zip")
        );

        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            loadFile(selectedFile);
        }
    }

    private void showImage(Image image) {
        preImage.setImage(image);
        saveBtn.setVisible(false); // Hide save button until processing is done
    }

    @FXML
    private void generateImage() {
        Image processedImage = null;
        if ("edge".equals(currentMode)) {
            processedImage = applyEdgeDetection(preImage.getImage(), currentEdgeMode);
            saveBtn.setVisible(true);
            if (isZipFile(currentFilePath)) {
                processAllImageWithEdgeDetection();
            }
        }

        postImage.setImage(processedImage);
        isGenerate = true;
        saveBtn.setVisible(true);
    }

    private Image applyEdgeDetection(Image image, String edgeMode) {
        switch (edgeMode) {
            case "prewitt":
                return imageProcessingService.prewittProcessingImage(image);
            case "roberts":
                return imageProcessingService.robertProcessingImage(image);
            case "laplacian":
                return imageProcessingService.laplacianProcessingImage(image);
            default:
                return image;
        }
    }

    private boolean isZipFile(File file) {
        String fileName = file.getName().toLowerCase();
        return fileName.endsWith(".zip");
    }

    private void processAllImageWithEdgeDetection() {
        processedImagesList.clear();
        List<Image> imgInZip = zipHandler.getImagesInZip();
        try {
            for (int i = 0; i < zipHandler.getImageCount(); i++) {
                Image originalImage = imgInZip.get(i);
                Image processedImage = applyEdgeDetection(originalImage, currentEdgeMode);
                processedImagesList.add(processedImage);
            }
            isGenerate = true;
            updateNavigationButtons();
        } catch (Exception e) {
            showError("Failed to process images in the ZIP file.");
        }
    }

    @FXML
    private void saveImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG Files", "*.png"),
                new FileChooser.ExtensionFilter("JPG Files", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG files", "*.jpeg")
        );
        File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            try {
                BufferedImage bufferedImage = convertToBufferedImage(postImage.getImage());
                FileChooser.ExtensionFilter selectedExtension = fileChooser.getSelectedExtensionFilter();
                String format = "png"; // set png as default

                if (selectedExtension != null) {
                    if (selectedExtension.getDescription().contains("JPG")) {
                        format = "jpg";
                    } else if (selectedExtension.getDescription().contains("JPEG")) {
                        format = "jpeg";
                    }
                }
                ImageIO.write(bufferedImage, format, file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public BufferedImage convertToBufferedImage(Image fxImage) {
        return SwingFXUtils.fromFXImage(fxImage, null);
    }

    private void setMode(String mode) {
        currentMode = mode;
        edgeParamsPane.setVisible("edge".equals(currentMode));
    }

    @FXML
    private void handleEdgeModeAction(ActionEvent event) {
        if (event.getSource() == prewittBtn) {
            setEdgeMode("prewitt");
        } else if (event.getSource() == robertsCrossBtn) {
            setEdgeMode("roberts");
        } else if (event.getSource() == laplacianBtn) {
            setEdgeMode("laplacian");
        }
    }

    private void setEdgeMode(String mode) {
        currentEdgeMode = mode;
        generateImage(); // Optionally generate image on mode change
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.showAndWait();
    }

    private String getFileType(File file) {
        if (isImageFile(file)) {
            return "image";
        } else if (file.getName().endsWith(".zip")) {
            return "zip";
        } else {
            return "unknown";
        }
    }

    private void updateNavigationButtons() {
        if (zipHandler != null) {
            prevBtn.setDisable(zipHandler.hasNext());
            nextBtn.setDisable(zipHandler.hasPrevious());
        }
    }

    @FXML
    private void navigateNext() {
        if (zipHandler != null) {
            zipHandler.getNextImage();
            showImage(zipHandler.getCurrentImage());
            updateFileNumber(zipHandler.getImageCount(), zipHandler.getCurrentIndex() + 1);
            updateNavigationButtons();
        }
    }

    @FXML
    private void navigatePrevious() {
        if (zipHandler != null) {
            zipHandler.getPreviousImage();
            showImage(zipHandler.getCurrentImage());
            updateFileNumber(zipHandler.getImageCount(), zipHandler.getCurrentIndex() + 1);
            updateNavigationButtons();
        }
    }

    //button handler
    @FXML
    private void handleEdgeButtonAction(ActionEvent event) {
        if (edgeBtn.isSelected()) {
            setMode("edge");
            cropBtn.setSelected(false);
        }
    }
    @FXML
    private void handlePrewittButtonAction(ActionEvent event) {
        if(prewittBtn.isSelected()) {
            setEdgeMode("prewitt");
            robertsCrossBtn.setSelected(false);
            laplacianBtn.setSelected(false);
        }
    }
    @FXML
    private void handleRobertsCrossButtonAction(ActionEvent event) {
        if (robertsCrossBtn.isSelected()) {
            setEdgeMode("roberts");
            laplacianBtn.setSelected(false);
            prewittBtn.setSelected(false);
        }
    }

    @FXML
    private void handleLaplacianButtonAction(ActionEvent event) {
        if(laplacianBtn.isSelected()) {
            setEdgeMode("laplacian");
            prewittBtn.setSelected(false);
            robertsCrossBtn.setSelected(false);
        }
    }

    @FXML
    private void handleCropButtonAction(ActionEvent event) {
        if (cropBtn.isSelected()) {
            setMode("crop");
            edgeBtn.setSelected(false);
        }
    }
}
