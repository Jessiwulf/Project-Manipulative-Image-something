package se233.ManipulativeImage.EdgeDetectFeature;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import se233.ManipulativeImage.EdgeDetectFeature.Algorithms.LaplacianAlgorithm;
import se233.ManipulativeImage.EdgeDetectFeature.Algorithms.RobertsCrossAlgorithm;
import se233.ManipulativeImage.EdgeDetectFeature.Algorithms.SobelAlgorithm;
import se233.ManipulativeImage.Utils.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Label;
import javafx.geometry.Insets;

public class EdgeDetectionController {
    // FXML Components
    @FXML private StackPane inputImageStack;  // The stack pane that contains the input image for processing
    @FXML private ImageView inputImageView;   // Displays the input image before edge detection
    @FXML private ImageView outputImageView;  // Displays the output image after edge detection

    @FXML private Label statusLabel;          // Label to show the current status of edge detection
    @FXML private Label dragDropLabel;        // Label providing instructions for drag and drop functionality

    @FXML private VBox adjustmentBox;         // VBox that contains adjustment controls for different algorithms

    @FXML private HBox robertsBox;            // Container for Roberts edge detection settings
    @FXML private Slider robertsStrengthSlider; // Slider to adjust the strength of Roberts edge detection
    @FXML private Label robertsStrengthLabel;  // Label to display the strength value for Roberts edge detection

    @FXML private HBox laplacianBox;          // Container for Laplacian edge detection settings
    @FXML private RadioButton radio3x3;       // Radio button for selecting a 3x3 mask size for Laplacian
    @FXML private RadioButton radio5x5;       // Radio button for selecting a 5x5 mask size for Laplacian
    @FXML private ToggleGroup laplacianMaskSize; // Toggle group to allow selection between different Laplacian mask sizes

    @FXML private HBox sobelBox;              // Container for Sobel edge detection settings
    @FXML private TextField sobelThresholdField; // Text field to input threshold for Sobel edge detection

    @FXML private ComboBox<String> algorithmChoice; // Drop-down to select different edge detection algorithms
    @FXML private ProgressBar progressBar;     // Progress bar to indicate the progress of edge detection
    @FXML private Button previousButton;       // Button to go to the previous image in the result set
    @FXML private Button nextButton;           // Button to go to the next image in the result set

    // Data structures for algorithms and images
    private Map<String, EdgeDetectAlgoConfig> algorithms;  // Stores configurations for different edge detection algorithms
    private final List<Image> imagesList = new ArrayList<>();  // List to store processed images
    private int currentIndex = 0;  // Index to keep track of the current image in the list of processed images

    @FXML
    public void initialize() {
        // Initialize the map of algorithms with different edge detection methods
        algorithms = new HashMap<>();
        algorithms.put("Sobel", new SobelAlgorithm());             // Add Sobel algorithm
        algorithms.put("Laplacian", new LaplacianAlgorithm());     // Add Laplacian algorithm
        algorithms.put("Roberts Cross", new RobertsCrossAlgorithm()); // Add Roberts Cross algorithm

        // Populate the ComboBox with algorithm options
        algorithmChoice.getItems().addAll("Sobel", "Laplacian", "Roberts Cross");
        algorithmChoice.setPromptText("Select Detect Edge Algorithm");  // Set default prompt text for the ComboBox

        // Initially hide the Roberts Cross control box
        robertsBox.setVisible(false);

        // Add listener to the Roberts strength slider to update its label with the current value
        robertsStrengthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            robertsStrengthLabel.setText(String.format("%.0f", newVal.doubleValue()));
        });

        // Initialize drag-and-drop functionality for images
        DragAndDropEdge();

        // Update navigation buttons (previous/next) based on current image state
        updateNavigationButtons();

        // Load CSS stylesheet after the scene is fully loaded using Platform.runLater to ensure UI is initialized
        Platform.runLater(() -> {
            String cssPath = "/se233/ManipulativeImage/styles/EdgeDetect.css";
            String css = getClass().getResource(cssPath).toExternalForm();
            inputImageView.getScene().getStylesheets().add(css);  // Apply the stylesheet to the inputImageView's scene
        });

        // Set up Sobel threshold field with a default value and prompt text
        sobelThresholdField = new TextField("50");
        sobelThresholdField.setPromptText("between 0-100 %)");

        // Create a HBox to contain the label and text field for Sobel threshold
        sobelBox = new HBox(10, new Label("Sobel Threshold Percentage:"), sobelThresholdField);
        sobelBox.setAlignment(Pos.CENTER);  // Center the components inside the HBox

        // Initially hide the Sobel adjustment box
        sobelBox.setVisible(false);
        sobelBox.setManaged(false);  // Prevent Sobel box from affecting layout when hidden

        // Add the Sobel adjustment box to the VBox that contains other adjustments
        adjustmentBox.getChildren().add(sobelBox);
    }

    private void DragAndDropEdge() {
        // Set the drag-over event handler to accept files dragged over the stack pane
        inputImageStack.setOnDragOver(event -> {
            // Check if the dragboard contains files
            if (event.getDragboard().hasFiles()) {
                // Accept the transfer mode if files are present, allowing copying
                event.acceptTransferModes(javafx.scene.input.TransferMode.COPY);
            }
            // Consume the event so that no other handlers process it
            event.consume();
        });

        // Set the drag-dropped event handler to process files dropped onto the stack pane
        inputImageStack.setOnDragDropped(event -> {
            boolean success = false; // Variable to track if a valid file was processed

            // Check if the dragboard contains files
            if (event.getDragboard().hasFiles()) {
                // Get the list of files from the dragboard
                List<File> files = event.getDragboard().getFiles();

                // Iterate over each file
                for (File file : files) {
                    // Check if the file is a zip file
                    if (file.getName().toLowerCase().endsWith(".zip")) {
                        processZipFile(file); // Process the zip file
                        success = true; // Mark success as true
                    }
                    // Check if the file is an image using the isImageFile method
                    else if (isImageFile(file)) {
                        loadImage(file); // Load the image
                        success = true; // Mark success as true
                    }
                }
            }

            // Set the drag drop completion status based on whether any valid file was processed
            event.setDropCompleted(success);
            // Consume the event to prevent further processing
            event.consume();
        });
    }

    // Checks if the given file name represents a valid image file
    private boolean isImageFile(String fileName) {
        // Convert the file name to lowercase for case-insensitive comparison
        String name = fileName.toLowerCase();

        // Return true if the file has a valid image extension, otherwise false
        return name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg");
    }

    // Overloaded version of the isImageFile method, which accepts a File object
    private boolean isImageFile(File file) {
        // Use the file name from the File object and delegate to the string version of isImageFile
        return isImageFile(file.getName());
    }

    // Updates the status label with the provided message
    private void handleStatusLabel(String message) {
        // Set the statusLabel's text to display the new status message
        statusLabel.setText("Status: " + message);
    }

    // Handles the action for the Previous button
    @FXML
    private void handlePreviousButton() {
        // Check if there is a previous image to display
        if (currentIndex > 0) {
            currentIndex--; // Decrement the index to go to the previous image
            displayCurrentImage(); // Update the view to display the current image
        }
    }

    // Handles the action for the Next button
    @FXML
    private void handleNextButton() {
        // Check if there is a next image to display
        if (currentIndex < imagesList.size() - 1) {
            currentIndex++; // Increment the index to go to the next image
            displayCurrentImage(); // Update the view to display the current image
        }
    }

    // Handles the action for the Clear button
    @FXML
    private void handleClearButton() {
        // Clear the list of images
        imagesList.clear();

        // Set the input and output image views to null, effectively clearing them
        inputImageView.setImage(null);
        outputImageView.setImage(null);

        // Make the drag-and-drop label visible again to prompt user actions
        dragDropLabel.setVisible(true);

        // Reset the current index to 0
        currentIndex = 0;

        // Update the navigation buttons' states (e.g., disable if no images)
        updateNavigationButtons();

        // Update the status label to inform the user that all images have been cleared
        handleStatusLabel("All images cleared");
    }

    // Displays the currently selected image in the input and output image views
    private void displayCurrentImage() {
        // Check if there are any images loaded
        if (!imagesList.isEmpty()) {
            // Get the current image based on the currentIndex
            Image currentImage = imagesList.get(currentIndex);

            // Set the current image in the input image view
            inputImageView.setImage(currentImage);

            // Clear the output image view as this method displays the current input image
            outputImageView.setImage(null);

            // Hide the drag-and-drop label since an image is being displayed
            dragDropLabel.setVisible(false);

            // Update the status label to show which image is currently being displayed
            handleStatusLabel("Showing image " + (currentIndex + 1) + " of " + imagesList.size());
        } else {
            // If no images are loaded, clear both image views
            inputImageView.setImage(null);
            outputImageView.setImage(null);

            // Make the drag-and-drop label visible to prompt the user to load images
            dragDropLabel.setVisible(true);

            // Update the status label to inform the user that no images are loaded
            handleStatusLabel("No images loaded");
        }
        // Update the state of the navigation buttons based on the current index
        updateNavigationButtons();
    }

    // Updates the visibility and enable/disable states of the navigation buttons
    private void updateNavigationButtons() {
        // Check if there are multiple images in the list
        boolean hasMultipleImages = imagesList.size() > 1;

        // Set the visibility of the Previous and Next buttons based on the number of images
        previousButton.setVisible(hasMultipleImages);
        nextButton.setVisible(hasMultipleImages);

        // Disable the Previous button if the current index is the first image
        previousButton.setDisable(currentIndex <= 0);

        // Disable the Next button if the current index is the last image
        nextButton.setDisable(currentIndex >= imagesList.size() - 1);
    }

    // Handles the action for saving the processed image displayed in the outputImageView
    @FXML
    private void handleSaveButton() {
        // Check if there is a processed image available to save
        if (outputImageView.getImage() == null) {
            // Show an alert if no image is available
            showAlert("Error", "No processed image to save.", Alert.AlertType.WARNING);
            return; // Exit the method if there is no image to save
        }

        // Create a FileChooser to select the save location
        FileChooser fileChooser = new FileChooser();
        // Add an extension filter for PNG files
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png"));

        // Show the save dialog and get the selected file
        File file = fileChooser.showSaveDialog(null);
        if (file != null) { // Check if a file was selected
            try {
                // Convert the JavaFX image to a BufferedImage and save it as a PNG
                ImageIO.write(ImageProcessor.fromFXImage(outputImageView.getImage()), "png", file);
                // Update the status label to indicate success
                handleStatusLabel("Image saved successfully");
            } catch (IOException e) {
                // Show an alert if there was an error during saving
                showAlert("Error", "Failed to save image: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    // Handles the action for saving all loaded images after processing
    @FXML
    private void handleSaveAllButton() {
        // Check if there are any images loaded for processing
        if (imagesList.isEmpty()) {
            // Show an alert if no images are available
            showAlert("Error", "No images to process. Please load images first.", Alert.AlertType.WARNING);
            return; // Exit the method if there are no images
        }

        // Get the selected algorithm from the algorithm choice combo box
        String algorithm = algorithmChoice.getValue();
        if (algorithm == null) { // Check if an algorithm is selected
            // Show an alert if no algorithm is selected
            showAlert("Error", "Please select an edge detection algorithm.", Alert.AlertType.WARNING);
            return; // Exit the method if no algorithm is selected
        }

        // Create a DirectoryChooser to select the output directory
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setTitle("Select Output Directory");

        // Show the directory selection dialog and get the selected directory
        File outputDir = directoryChooser.showDialog(null);
        if (outputDir != null) { // Check if a directory was selected
            // Process all images in a separate thread to avoid blocking the UI
            processBatchMultithreaded(outputDir, algorithm);
        }
    }

    // Handles the event triggered when the user selects a different edge detection algorithm
    @FXML
    private void handleAlgorithmChangeButton() {
        // Get the currently selected algorithm from the algorithm choice combo box
        String selectedAlgorithm = algorithmChoice.getValue();

        // Make the adjustment box visible, allowing the user to see the relevant adjustment options
        adjustmentBox.setVisible(true);
        adjustmentBox.setManaged(true);

        // Initially hide all adjustment boxes for different algorithms
        robertsBox.setVisible(false);
        robertsBox.setManaged(false);
        laplacianBox.setVisible(false);
        laplacianBox.setManaged(false);
        sobelBox.setVisible(false);
        sobelBox.setManaged(false);

        // Show the specific adjustment box based on the selected algorithm
        switch (selectedAlgorithm) {
            case "Roberts Cross":
                // If "Roberts Cross" is selected, make its adjustment box visible
                robertsBox.setVisible(true);
                robertsBox.setManaged(true);
                break;
            case "Laplacian":
                // If "Laplacian" is selected, make its adjustment box visible
                laplacianBox.setVisible(true);
                laplacianBox.setManaged(true);
                break;
            case "Sobel":
                // If "Sobel" is selected, make its adjustment box visible
                sobelBox.setVisible(true);
                sobelBox.setManaged(true);
                break;
            default:
                // If no valid algorithm is selected, hide the adjustment box
                adjustmentBox.setVisible(false);
                adjustmentBox.setManaged(false);
        }
    }

    // Handles the event triggered when the user clicks the "Apply Edge Detection" button
    @FXML
    private void applyEdgeDetectionButton() {
        // Check if there are any images loaded and the current index is valid
        if (imagesList.isEmpty() || currentIndex < 0 || currentIndex >= imagesList.size()) {
            showAlert("Error", "Please load an image first.", Alert.AlertType.WARNING);
            return; // Exit the method if no image is loaded
        }

        // Get the currently selected image
        Image currentImage = imagesList.get(currentIndex);

        // Retrieve the selected edge detection algorithm from the combo box
        String algorithmName = algorithmChoice.getValue();
        if (algorithmName == null) {
            showAlert("Error", "Please select an algorithm.", Alert.AlertType.WARNING);
            return; // Exit the method if no algorithm is selected
        }

        // Create a task for processing the image in the background
        Task<Image> task = new Task<>() {
            @Override
            protected Image call() throws Exception {
                updateProgress(0, 100); // Initialize progress

                // Retrieve the algorithm configuration based on the selected algorithm
                EdgeDetectAlgoConfig algorithm = algorithms.get(algorithmName);

                // Get parameters for the algorithm
                int strength = (int) robertsStrengthSlider.getValue(); // For Roberts Cross
                int maskSize = radio5x5.isSelected() ? 5 : 3; // Size for Laplacian
                int threshold = 50; // Default threshold for Sobel
                if (algorithmName.equals("Sobel")) {
                    // Parse the threshold value from the text field
                    threshold = Integer.parseInt(sobelThresholdField.getText());
                    if (threshold < 0 || threshold > 100) {
                        throw new NumberFormatException(); // Check for valid range
                    }
                }

                updateProgress(50, 100); // Update progress after parameter setup

                // Apply the edge detection algorithm to the image
                Image processedImage = algorithm.apply(currentImage,
                        algorithmName.equals("Laplacian") ? maskSize :
                                (algorithmName.equals("Sobel") ? threshold : strength));
                updateProgress(100, 100); // Mark task as complete
                return processedImage; // Return the processed image
            }
        };

        // Bind the progress bar's progress property to the task's progress
        progressBar.progressProperty().bind(task.progressProperty());

        // Define what happens when the task succeeds
        task.setOnSucceeded(e -> {
            outputImageView.setImage(task.getValue()); // Set the processed image
            handleStatusLabel("Edge detection applied successfully"); // Update status
            progressBar.progressProperty().unbind(); // Unbind progress
            progressBar.setProgress(0); // Reset progress bar
        });

        // Define what happens when the task fails
        task.setOnFailed(e -> {
            showAlert("Error", task.getException().getMessage(), Alert.AlertType.ERROR); // Show error alert
            progressBar.progressProperty().unbind(); // Unbind progress
            progressBar.setProgress(0); // Reset progress bar
        });

        // Start the task in a new thread to avoid blocking the UI
        new Thread(task).start();
    }

    // Loads an image from the specified file and updates the display
    private void loadImage(File file) {
        // Create a new Image object using the file's URI
        Image image = new Image(file.toURI().toString());
        imagesList.add(image); // Add the image to the list of loaded images
        currentIndex = imagesList.size() - 1; // Update the current index to the newly added image
        displayCurrentImage(); // Display the newly loaded image
        dragDropLabel.setVisible(false); // Hide the drag-and-drop label as an image is now loaded
    }

    // Handles the event triggered when the user clicks the "Upload Image" button
    @FXML
    private void handleUploadImageButton() {
        FileChooser fileChooser = new FileChooser(); // Create a new FileChooser instance
        // Set up extension filters to allow image and zip files
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("ZIP Files", "*.zip")
        );
        // Show the open dialog to allow the user to select a file
        File selectedFile = fileChooser.showOpenDialog(null);

        // Check if the user selected a file
        if (selectedFile != null) {
            // If the selected file is a ZIP file, process it
            if (selectedFile.getName().toLowerCase().endsWith(".zip")) {
                processZipFile(selectedFile);
            } else {
                // Otherwise, load the selected image file
                loadImage(selectedFile);
            }
        }
    }

    // Processes the specified ZIP file to extract and load image files
    private void processZipFile(File zipFile) {
        // Try-with-resources to automatically manage the ZipInputStream resource
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry; // Represents each entry in the ZIP file
            // Iterate through the entries in the ZIP file
            while ((entry = zis.getNextEntry()) != null) {
                // Check if the entry is a file and if it is an image file
                if (!entry.isDirectory() && isImageFile(entry.getName())) {
                    // Create a temporary file for each image extracted from the ZIP
                    File tempFile = File.createTempFile("temp", "." + getFileExtension(entry.getName()));
                    tempFile.deleteOnExit(); // Ensure the temporary file is deleted on exit

                    // Write the contents of the ZIP entry to the temporary file
                    try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                        byte[] buffer = new byte[1024]; // Buffer to hold data while reading
                        int len;
                        // Read from the ZIP input stream and write to the temporary file
                        while ((len = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }

                    // Create an Image object from the temporary file
                    Image image = new Image(tempFile.toURI().toString());
                    // Check if the image is valid (i.e., has a non-zero width and height)
                    if (image.getWidth() > 0 && image.getHeight() > 0) {
                        imagesList.add(image); // Add the valid image to the list
                    }
                }
                zis.closeEntry(); // Close the current entry
            }
            // If any images were loaded, update the current index and display the first image
            if (!imagesList.isEmpty()) {
                currentIndex = 0; // Set current index to the first image
                displayCurrentImage(); // Display the first loaded image
            }
            handleStatusLabel("ZIP file processed successfully. Loaded " + imagesList.size() + " images.");
        } catch (IOException e) {
            // Handle any IOException that occurs during ZIP processing
            showAlert("Error", "Failed to process ZIP file: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // Returns the file extension of the given file name
    private String getFileExtension(String fileName) {
        int lastIndexOf = fileName.lastIndexOf("."); // Find the last dot in the file name
        // If no dot is found, return an empty string
        if (lastIndexOf == -1) {
            return "";
        }
        // Return the substring after the last dot (the file extension)
        return fileName.substring(lastIndexOf + 1);
    }

    // Processes a batch of images using multithreading
    private void processBatchMultithreaded(File outputDir, String algorithm) {
        // Create a Task to perform batch processing
        Task<Void> batchTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                int total = imagesList.size(); // Get the total number of images
                EdgeDetectAlgoConfig edgeAlgorithm = algorithms.get(algorithm); // Get the selected edge detection algorithm

                // Check if the algorithm is valid
                if (edgeAlgorithm == null) {
                    throw new IllegalArgumentException("Unknown algorithm: " + algorithm);
                }

                // Get the number of available processors for parallel execution
                int numThreads = Runtime.getRuntime().availableProcessors();
                ExecutorService executorService = Executors.newFixedThreadPool(numThreads); // Create a thread pool

                AtomicInteger completedTasks = new AtomicInteger(0); // To keep track of completed tasks

                List<Future<?>> futures = new ArrayList<>(); // List to hold Future objects representing the tasks

                // Submit tasks for each image in the images list
                for (int i = 0; i < total; i++) {
                    final int index = i; // Final variable for use in lambda expression
                    futures.add(executorService.submit(() -> {
                        try {
                            // Retrieve the original image
                            Image originalImage = imagesList.get(index);
                            int strength = (int) robertsStrengthSlider.getValue(); // Get strength for the algorithm
                            int maskSize = radio5x5.isSelected() ? 5 : 3; // Determine mask size
                            int threshold = algorithm.equals("Sobel") ? Integer.parseInt(sobelThresholdField.getText()) : 0; // Set threshold for Sobel

                            // Apply the edge detection algorithm
                            Image processedImage = edgeAlgorithm.apply(originalImage,
                                    algorithm.equals("Laplacian") ? maskSize :
                                            (algorithm.equals("Sobel") ? threshold : strength));

                            // Extract the original filename and create a new filename
                            String originalFilename = new File(originalImage.getUrl().substring(5)).getName();
                            String baseName = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
                            String extension = originalFilename.substring(originalFilename.lastIndexOf('.'));
                            String newFilename = baseName + "_detected" + extension;

                            // Create output file in the specified directory
                            File outputFile = new File(outputDir, newFilename);

                            // Handle naming conflicts by appending a counter
                            int counter = 1;
                            while (outputFile.exists()) {
                                newFilename = baseName + "_detected_" + counter + extension;
                                outputFile = new File(outputDir, newFilename);
                                counter++;
                            }

                            // Write the processed image to the output file
                            ImageIO.write(ImageProcessor.fromFXImage(processedImage), "png", outputFile);

                            // Update progress and status message
                            int completed = completedTasks.incrementAndGet();
                            updateProgress(completed, total);
                            updateMessage(String.format("Processed %d%% (%d of %d images)",
                                    (completed * 100) / total, completed, total));
                        } catch (Exception e) {
                            e.printStackTrace(); // Print the exception stack trace for debugging
                        }
                    }));
                }

                // Wait for all tasks to complete
                for (Future<?> future : futures) {
                    future.get(); // This will block until the task is completed
                }

                executorService.shutdown(); // Shutdown the executor service after processing
                return null;
            }
        };

        // Create a progress stage to show the processing status
        Stage progressStage = new Stage();
        progressStage.setTitle("Batch Processing");
        ProgressBar progressBar = new ProgressBar();
        progressBar.progressProperty().bind(batchTask.progressProperty()); // Bind progress bar to task progress
        Label statusLabel = new Label();
        statusLabel.textProperty().bind(batchTask.messageProperty()); // Bind label to task message
        VBox vbox = new VBox(10, new Label("Processing images..."), progressBar, statusLabel);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));

        progressStage.setScene(new Scene(vbox, 300, 150)); // Set the scene for the progress stage
        progressStage.show(); // Display the progress stage

        // Set up task completion handlers
        batchTask.setOnSucceeded(e -> {
            progressStage.close(); // Close the progress stage on success
            showAlert("Success", "Batch processing completed. Images saved to " + outputDir.getAbsolutePath(), Alert.AlertType.INFORMATION);
        });

        batchTask.setOnFailed(e -> {
            progressStage.close(); // Close the progress stage on failure
            showAlert("Error", "Batch processing failed: " + batchTask.getException().getMessage(), Alert.AlertType.ERROR);
        });

        // Start the batch processing task in a new thread
        new Thread(batchTask).start();
    }

    //Just normal alert
    private void showAlert(String title, String content, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}