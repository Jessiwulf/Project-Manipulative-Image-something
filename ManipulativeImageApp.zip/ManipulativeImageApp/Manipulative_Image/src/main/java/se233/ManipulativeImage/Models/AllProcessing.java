package se233.ManipulativeImage.Models;

import java.io.File;

public class AllProcessing {
    private File inputFile; // The input file to be processed
    private File outputFile; // The file where the processed output will be saved
    private String algorithm; // The algorithm used for processing
    private int strength; // The strength or intensity of the processing effect
    private int maskSize; // The size of the mask used in processing

    // Returns the input file
    public File getInputFile() {
        return inputFile;
    }

    // Sets the input file
    public void setInputFile(File inputFile) {
        this.inputFile = inputFile;
    }

    // Returns the output file
    public File getOutputFile() {
        return outputFile;
    }

    // Sets the output file
    public void setOutputFile(File outputFile) {
        this.outputFile = outputFile;
    }

    // Returns the algorithm used for processing
    public String getAlgorithm() {
        return algorithm;
    }

    // Sets the algorithm to be used for processing
    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    // Returns the strength of the processing effect
    public int getStrength() {
        return strength;
    }

    // Sets the strength of the processing effect
    public void setStrength(int strength) {
        this.strength = strength;
    }

    // Returns the mask size used in processing
    public int getMaskSize() {
        return maskSize;
    }

    // Sets the mask size for processing
    public void setMaskSize(int maskSize) {
        this.maskSize = maskSize;
    }

    // Constructor to initialize the ProcessingJob with specified parameters
    public AllProcessing(File inputFile, File outputFile, String algorithm, int strength, int maskSize) {
        this.inputFile = inputFile; // Initialize input file
        this.outputFile = outputFile; // Initialize output file
        this.algorithm = algorithm; // Initialize processing algorithm
        this.strength = strength; // Initialize processing strength
        this.maskSize = maskSize; // Initialize mask size
    }
}
