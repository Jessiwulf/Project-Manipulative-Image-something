module se233.cropedgestudio {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;
    requires javafx.swing;
    requires java.logging;

    opens se233.ManipulativeImage to javafx.fxml;
    opens se233.ManipulativeImage.Main to javafx.fxml;
    exports se233.ManipulativeImage;
    opens se233.ManipulativeImage.CroppingFeature to javafx.fxml;
    opens se233.ManipulativeImage.EdgeDetectFeature to javafx.fxml;
    opens se233.ManipulativeImage.EdgeDetectFeature.Algorithms to javafx.fxml;
}